package com.fdmgroup.pensions.task3;

public class PensionController {

	private Person model ;
	private View view;
	
	
	public Person getModel() {
		return model;
	}


	public void setModel(Person model) {
		this.model = model;
	}


	public View getView() {
		return view;
	}


	public void setView(View view) {
		this.view = view;
	}


	public void handlePensions() {
		
		
		
		
		
	}
	
}
