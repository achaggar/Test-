package com.fdmgroup.pensions.task3;

public class View {

	public String firstname, lastname;
	public void printEligible(Person person) {
		
		System.out.println(firstname + lastname + "may qualify for a pension this year.");
	}
	
	public void printIneligible(Person person) {
		
		System.out.println(firstname + lastname + "is not old enough yet.");
	}
}
