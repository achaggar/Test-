package com.fdmgroup.pensions.task3;

public class Client {

	public static void main(String[] args) {
		
//		PensionController pc = new PensionController();
//		pc.handlePensions(people);
		
		
	}
}
