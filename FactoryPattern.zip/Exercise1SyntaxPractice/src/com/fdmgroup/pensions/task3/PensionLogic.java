package com.fdmgroup.pensions.task3;

public class PensionLogic {

	public boolean isPensionable(Person person, String year) {
		
	
		return false;
		
	}
	
	
}
