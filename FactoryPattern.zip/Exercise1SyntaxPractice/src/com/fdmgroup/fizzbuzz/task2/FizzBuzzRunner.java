package com.fdmgroup.fizzbuzz.task2;

public class FizzBuzzRunner {

	public void FizzBuzz(int num){ 
		
		if (Fizz(num))
		{
			System.out.println("divisible by 3");
		}
		else 
		{
			System.out.println("not divisible by 3");
		}
		
			
		if (Buzz(num))
		{
			System.out.println("divisible by 5");
		}
		else 
		{
			System.out.println("not divisible by 5");
		}
		
		
		if (fizzBuzz(num))
		{
			System.out.println("divisible by 3 & 5");
		}
		else 
		{
			System.out.println("not divisible by 3 & 5");
		}					
    }
		
	
	private boolean Fizz(int num) {  
		if (num % 3 == 0){  
			return true ;  }
		
		else return false; }
	

	private boolean Buzz(int num) {  
		if (num % 5 == 0){  
			return true ;  } 
		else return false;  }

	
	private boolean fizzBuzz(int num) { 
		if ( num % 15 == 0){ 
			return true ;  }  
		else return false;    }
	
	
}


 