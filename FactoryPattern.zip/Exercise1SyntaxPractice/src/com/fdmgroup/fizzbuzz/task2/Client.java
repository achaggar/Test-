package com.fdmgroup.fizzbuzz.task2;

public class Client {

	public static void main(String[] args) {
		
		FizzBuzzRunner fz = new FizzBuzzRunner();
		fz.FizzBuzz(9);
		
		
	
		
		
	}

}
