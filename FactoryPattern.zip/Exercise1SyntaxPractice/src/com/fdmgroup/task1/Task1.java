package com.fdmgroup.task1;

public class Task1 {

		public static void main (String[] args) {
			int i ;
			int count = 100;
			
			
			for (i=1;i<=count;i++)
			{
				if (i % 15 == 0) { System.out.println("FizzBuzz");  }
			
				
				else if (i % 3== 0) { System.out.println("Fizz");  }
			
				else if (i % 5== 0) { System.out.println("Buzz");  } 
				
                if (i % 5!= 0  && i % 3!= 0) { System.out.println(i); }
			
		     }
		}}




