package com.fdmgroup;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefination {

	private DriverUtilities driverUtilities;
	private WebDriver driver;
	
	
	@Given("^Open the browser$")
	public void openBrowser() {
		driverUtilities = DriverUtilities.getInstance();
		driver = driverUtilities.getDriver();
		
	}
	
	
	@When("^Launch the trading platform application$")
	public void launchApplication() {
		driver.get("http://unxbtn001/TradingPlatform_CLEAN/");
	}
	
	@Then("^Login button should exist$")
	public void loginButton() {
		WebElement loginButton = driver.findElement(By.name("submit"));
		if (loginButton.isDisplayed()) {
			System.out.println("Test case passed");
		}
		else {
			System.out.println("Test case failed");
		}
	}
	
	
	@When("^I enter username and password$")
	public void enterCredentials() {
		driver.findElement(By.name("j_username")).sendKeys("BradFord1");
		driver.findElement(By.name("j_password")).sendKeys("Montreal8");
	}
	
	@When("^click on submit button$")
	public void clickSubmit() {
		driver.findElement(By.name("submit")).click();
	}
	
	
	
	@Then("^I see the homepage of Application$")
	public void HomePage() {
		String actual = driver.findElement(By.tagName("h3")).getText();
		assertEquals("Hello Brad",actual);
		driver.findElement(By.linkText("logout")).click();
	}


	@When("^I click on register link$")
	public void registerLink() {
		driver.findElement(By.linkText("Register")).click();
	}
	
	
	@When("^Enter firstname \'(.*)\' and lastname \'(.*)\'$")//use regular expressions (regex)
	public void enterDetails(String firstname, String lastname) {
		driver.findElement(By.name("firstName")).sendKeys(firstname);
		driver.findElement(By.name("lastName")).sendKeys(lastname);
		
	}
	
	@Then("^Click on reset button$")
	public void resetButton() {
		driver.findElement(By.xpath("//*[@id=\"user\"]/table/tbody/tr[11]/td[2]/input[2]"));
	}
}


