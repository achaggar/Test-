package App;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainApp {

	public static void main (String[] args) {
	
		//list is dynamic and the size is not fixed 
		//Integer is wrapper class 
		//List is an Interface and ArrayList is a concrete class
		//List without the <> can add any type of the object in the collections
		//<> binds the list to certain data type
		
		//alt + shift+ hs - for a hash
		//hashcode generates the integer value for ev
		
		Book b1 = new Book(1,"java","abc",500,10);
		Book b2 = new Book(1,"C++","abc",500,10);
		Book b3 = new Book(1,"C","abc",500,10);
	
	

		
		List<Book> books =  new ArrayList<>();
		books.add(b1);
		books.add(b2);
		books.add(b3);
		
		
		Comparator<Book> bookscom = new Comparator<Book>() {

			@Override
			public int compare(Book o1, Book o2) {
				if(o1.getPrice() == o2.getPrice())
				{
				return 0;
				}
				
				else if (o1.getPrice()> o2.getPrice()) {
					return 1;
				}
				else {
					return -1;
					
				}
				
				}
				};
		
		Collections.sort(books, bookscom);
		System.out.println(books);
		
		
	}
}
