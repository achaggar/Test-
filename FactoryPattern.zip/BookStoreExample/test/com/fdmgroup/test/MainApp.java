package com.fdmgroup.test;

import java.util.ArrayList;
import java.util.List;

import com.fdmgroup.app.Book;

public class MainApp {

	public static void main(String args[]) {

		List <Book> book= new ArrayList<>();
		
	Book book1 = new Book(1,"Java","Oracle",12.5,400);
	Book book2 = new Book(2,"C++","Oracle",12.5,400);
		System.out.println(book1);
		System.out.println(book2);
		
		
		
		
	}


	
}
