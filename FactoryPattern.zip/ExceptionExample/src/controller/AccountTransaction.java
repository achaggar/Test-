package controller;

import com.fdmgroup.exception.CustomeException;

import model.Account;

public class AccountTransaction {

	
	public int withdraw(Account account, int amount ) throws CustomeException {
		
		if (account.getBalance()> amount) {
			account.setBalance(account.getBalance() - amount);
			return account.getBalance();
			
		}
		else 
		{
			throw new CustomeException();
		}
		
	}
	
	
}
