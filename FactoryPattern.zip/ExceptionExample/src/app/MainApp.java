package app;

//import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.List;

import com.fdmgroup.exception.CustomeException;

import controller.AccountTransaction;
import model.Account;

public class MainApp {
	
	public static void main (String[] args) {
		
		Account account = new Account(1,100, "Amrit");
		AccountTransaction at = new AccountTransaction();
		try {
			at.withdraw(account, 70);
		} catch (CustomeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Balance is "+ account.getBalance());
		
		
		
	}
	
	
//	
	/*
	
	List<Integer> numbers;
	public static void main(String[] args) {
		
		sum();
		
		
		
		
	}
	public static  void sum()  {
		
		
		try {
			sumext();
		}
		
		catch (CustomeException e) {
			System.out.println(e.getMessage());
		}
		
	
		
		
		try {
			sumext();          //can throw an exception 
		} catch (FileNotFoundException e) {
			
		System.out.println(e.getMessage());
		}
	 catch (ArithmeticException e) {
		
		System.out.println(e.getMessage());
	} 
		
		finally {System.out.println("In the finally block");
		
	}
	}
	
	public static void sumext() throws  CustomeException {
		System.out.println(2/0); //unchecked exception
		PrintWriter o = new PrintWriter("abc.text");//checked exception
	
		
	throw new CustomeException();
	}
	*/
	
}
