package App;

import java.util.Calendar;

import model.Employee;
import model.Role;

public class MainApp {
	
	public static void main (String[] Args)
	{
		
		/*Employee emp = new Employee(1,"John",Role.SuperAdmin);
		System.out.println(Role.Admin.getDescription());
		System.out.println(emp);*/
		
		Calendar cal= Calendar.getInstance();
		System.out.println(cal.getTime().toString());
		System.out.println(cal.HOUR_OF_DAY);
				
	}

}
