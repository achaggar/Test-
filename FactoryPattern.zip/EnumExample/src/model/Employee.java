package model;

public class Employee {

	private int ID;
	private String name;
	private Role role;
	
	
    //enums are more efficient than a normal string 
	
	
	
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	public Employee(int iD, String name, Role role) {
		super();
		ID = iD;
		this.name = name;
		this.role = role;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Employee [ID=" + ID + ", name=" + name + ", role=" + role + "]";
	}
	
	
	
}
