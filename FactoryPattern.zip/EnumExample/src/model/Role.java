package model;

public enum Role {

	SuperAdmin("Can create Admins"),Admin("Manage Users"),Operator("Data Entry"), user("Normal User");
	
	String description;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	private Role(String description) {
		this.description = description;
	}
	
}
