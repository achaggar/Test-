package com.fdmgroup.controller;
//import java.util.ArrayList;
//import java.util.List;
public class Book {

	public double price;
	
	public Book(double price) {
		this.price=price;
		
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	

}
