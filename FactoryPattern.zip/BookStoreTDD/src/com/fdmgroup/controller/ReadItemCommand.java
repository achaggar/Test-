package com.fdmgroup.controller;

public class ReadItemCommand {

	public void readAll() {
		
		
	}

}
