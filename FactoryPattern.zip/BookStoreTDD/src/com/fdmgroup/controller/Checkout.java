package com.fdmgroup.controller;
//import java.util.ArrayList;
public class Checkout {

	public double calculatePrice(Basket basket) {
//		Book book;
		
		double price= 0.0;
		
		
		// To get the price of the books present in the basket
		
		for (int i=0;i<basket.books.size();i++) {
			price= price + basket.books.get(i).price;
		}
		
	int discount1,discount2;
	double discount, discountAmount;
	
	if (basket.books.size() >=10) {
		
	discount1 = (int) (basket.books.size()/10)* 10;
	discount2 = (int) basket.books.size()/3;
	discountAmount = discount1+ discount2;
	
	}
	else 
	{
		discountAmount = (int) basket.books.size()/3;
		
	}
	
	discount = price*discountAmount/100;
	price=price-discount;
	
	
	return price;
}
}