package com.fdmgroup.controller;

import java.util.ArrayList;
import java.util.List;
//import java.util.List;

public class Catalogue {

	ReadItemCommand mockread;
	List<Book> ReturnedBookList= new ArrayList<>();

	
	public Catalogue(ReadItemCommand mockread) {
		super();
		this.mockread = mockread;
	}
	
	
//constructor 
	public Catalogue() {
		
	}

	public List<Book> getAllBooks() {
		mockread.readAll();
		
		return ReturnedBookList; 
	}

}
