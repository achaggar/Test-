package com.fdmgroup.controller;

import java.util.ArrayList;
import java.util.List;

public class Basket {

	List<Book> books = new ArrayList<>();
	public Object book;

	public List<Book> getBooksInTheBasket() {
	
		return books;
	}

	
	public void addBook(Book book) {
		books.add(book);
	}

	

}
