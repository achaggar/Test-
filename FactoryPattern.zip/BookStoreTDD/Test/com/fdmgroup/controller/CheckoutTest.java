package com.fdmgroup.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

//import java.util.ArrayList;

//import org.junit.Before;
import org.junit.Test;

public class CheckoutTest {

// books = new ArrayList<>();
	Basket basket = new Basket();
	Checkout checkout = new Checkout();
    Book book;
	
	@Test
	//Test 1
	public void test_CalculatePrice_ReturnsDoubleZeroPointZeroWhenPassedAnEmptyBasket(){

		
		double price= checkout.calculatePrice(basket);
		assertTrue(price==0.0);	
	}
 
	
	@Test
	//Test 2
	
	public void test_CalculatePrice_ReturnsPriceOfBookInBasket_WhenPassedBasketWithOneBook(){
		book = new Book(3.0);
		basket.addBook(book);
		double price = checkout.calculatePrice(basket);
		assertEquals(3.0,price, 0.01);
	
	}

	@Test
	//Test 3
	public void test_CalculatePrice_ReturnspriceofTwoBooksInBasket() {
		Book book = new Book(3.0);
		Book book2 = new Book(3.0);
		basket.addBook(book);
		basket.addBook(book2);
		double price = checkout.calculatePrice(basket);
		assertEquals(6,price,0.01);
	
	}
	
	@Test
	//Test 4
	
	public void test_CalculatePrice_ReturnsPriceOfThreeBooksInTheBasket() {
		Book book1 = new Book(3);
		Book book2 = new Book(3);
		Book book3 = new Book(3);
		basket.addBook(book1);
		basket.addBook(book2);
		basket.addBook(book3);
		double price = checkout.calculatePrice(basket);
		assertEquals(8.91,price,0.01);
	}
	
	@Test
	
	//Test 5
	
	public void test_CalculatePrice_ReturnsPriceOfSevenBooksInTheBasket() {
		Book book1 = new Book(25.99);
		Book book2 = new Book(25.99);
		Book book3 = new Book(25.99);
		Book book4 = new Book(25.99);
		Book book5 = new Book(25.99);
		Book book6 = new Book(25.99);
		Book book7 = new Book(25.99);
		basket.addBook(book1);
		basket.addBook(book2);
		basket.addBook(book3);
		basket.addBook(book4);
		basket.addBook(book5);
		basket.addBook(book6);
		basket.addBook(book7);
		double price = checkout.calculatePrice(basket);
		assertEquals(178.29,price,0.01);
		
		
	}
	
	@Test
	
	//Test 6
	public void test_CalculatePrice_ReturnsPriceOfTenBooksInTheBasket() {
		Book book1 = new Book(3);
		Book book2 = new Book(3);
		Book book3 = new Book(3);
		Book book4 = new Book(3);
		Book book5 = new Book(3);
		Book book6 = new Book(3);
		Book book7 = new Book(3);
		Book book8 = new Book(3);
		Book book9 = new Book(3);
		Book book10 = new Book(3);
			
		basket.addBook(book1);
		basket.addBook(book2);
		basket.addBook(book3);
		basket.addBook(book4);
		basket.addBook(book5);
		basket.addBook(book6);
		basket.addBook(book7);
		basket.addBook(book8);
		basket.addBook(book9);
		basket.addBook(book10);
		double price = checkout.calculatePrice(basket);
		assertEquals(26.1,price,0.01);
	

	//Test 7 
		
		/*public void test_CalculatePrice_ReturnsPriceOfTenBooksInTheBasket() {
			Book book1 = new Book(3);
			Book book2 = new Book(3);
			Book book3 = new Book(3);
			Book book4 = new Book(3);
			Book book5 = new Book(3);
			Book book6 = new Book(3);
			Book book7 = new Book(3);
			Book book8 = new Book(3);
			Book book9 = new Book(3);
			Book book10 = new Book(3);
			Book book11 = new Book(3);
			Book book11 = new Book(3);
				
			basket.addBook(book1);
			basket.addBook(book2);
			basket.addBook(book3);
			basket.addBook(book4);
			basket.addBook(book5);
			basket.addBook(book6);
			basket.addBook(book7);
			basket.addBook(book8);
			basket.addBook(book9);
			basket.addBook(book10);
			basket.addBook(book11);
			basket.addBook(book12);
			double price = checkout.calculatePrice(basket);
			assertEquals(26.1,price,0.01);
		
		*/
	
}
}