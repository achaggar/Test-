package com.fdmgroup.controller;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

//import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BasketTest {

	
	Basket basket;
	Book book;
	Book book1;
	List<Book> books;
	
	
@Before
	public void init () {
	basket = new Basket();
	book= new Book(3.0);
	book1= new Book(3.97);
	books = new ArrayList<>();


}
	
	
	// Check if the shopping cart is empty 
	@Test
	public void test_GetBooksInBasket_ReturnsEmptyBookList_IfNoBooksHaveBeenAdded(){
		books = basket.getBooksInTheBasket();
		assertEquals(0,books.size());
		}
	
	
	//To add 1 book in the shopping cart 
	
	@Test 

	public void test_GetBooksInBasket_ReturnsArrayOfLengthOne_AfterAddBookMethodIsCalledWithOneBook(){
		
		basket.addBook(book);
		books = basket.getBooksInTheBasket();
	    System.out.println(books);
		assertEquals(1,books.size());
			
	}
	
	//To add 2 book in the shopping cart 
	@Test 
	
	public void test_GetBooksInBasket_ReturnsArrayOfLengthTwo_AfterAddBookMethodIsCalledWithTwoBooks(){
		
		basket.addBook(book);
		basket.addBook(book1);
		books = basket.getBooksInTheBasket();
		System.out.println(books);
		assertEquals(2,books.size());
		
 } 
 } 