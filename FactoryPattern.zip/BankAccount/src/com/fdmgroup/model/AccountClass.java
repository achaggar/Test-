package com.fdmgroup.model;

public class AccountClass {

}
