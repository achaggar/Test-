package com.fdmgroup.model;

public class CustomerClass {

}
