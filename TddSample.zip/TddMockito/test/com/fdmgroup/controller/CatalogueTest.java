package com.fdmgroup.controller;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;


public class CatalogueTest {
	
	
	List <Book> books;
	ReadItemCommand mockread = mock( ReadItemCommand.class);
	WriteitemCommand mockwrite = mock(WriteitemCommand.class);
	Catalogue catalogue = new Catalogue(mockread,mockwrite);
	ArrayList<Book> mocklist; 
	
	
@Before

public void init() {
	
	Book book;
	books = new ArrayList<>();
	mocklist= mock(ArrayList.class);
	
}

@Test
	public void test_GetAllBooks_ReturnsEmptyBookList_IfNoBooksAreInTheCatalogue(){
		books = catalogue.GetAllBooks();
		assertEquals(0,books.size());

	}

	
@Test 

public void test_GetAllBooks_CallsReadAllMethodOfReadItemCommand_WhenCalled(){
	catalogue.GetAllBooks();
	verify(mockread, times(1)).readAll();

}

@Test
public void test_GetAllBooks_ReturnsListOfBooksItReceivesFromReadAllMethodOfReadItemCommand_WhenCalled(){
	
	when(mockread.readAll()).thenReturn(mocklist);
	catalogue.GetAllBooks();
	assertEquals(mocklist.size(),catalogue.GetAllBooks().size());
	
	
}
/*@Test
public void test_AddBook_CallsInsertItemMethodOfWriteItemCommand_WhenCalled(){
	catalogue.addBook();
	verify(mockwrite,times(1)).insertItem();
	
}*/
}
