package com.fdmgroup.controller;

public class Book {
	
	int ID;
	String name;
	String Author;
	int Pages;
	double Price;
	
	
	public Book(int iD, String name, String author, int pages, double price) {
		super();
		ID = iD;
		this.name = name;
		Author = author;
		Pages = pages;
		Price = price;
	}
	
	

}
