package com.fdmgroup.controller;



public interface WriteitemCommand {

	public void insertItem(Book book);

}
