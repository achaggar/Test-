package com.fdmgroup.controller;

//import java.util.ArrayList;
import java.util.List;

public interface ReadItemCommand {

	public List<Book> readAll() ;

		
	

}
