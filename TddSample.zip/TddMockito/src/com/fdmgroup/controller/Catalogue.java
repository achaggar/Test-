package com.fdmgroup.controller;

import java.util.ArrayList;
import java.util.List;

public class Catalogue {
	
	List<Book> books = new ArrayList<>();
	 ReadItemCommand mockread;
	WriteitemCommand WriteItem;
	
	
	public Catalogue() {
		super();
	
	}

	public Catalogue(ReadItemCommand mockread, WriteitemCommand mockwrite) {
		super();
		this.mockread = mockread;
	}


	public List<Book> GetAllBooks() {

		mockread.readAll();
		return books;		
	}

	public void addBook() {
		
		Book book = null;
		WriteItem.insertItem(book);
	}
}
