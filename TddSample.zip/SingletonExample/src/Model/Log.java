package Model;

public class Log {
	
	
	
	private Log log;
	private Log() {
		
	}
	
	public Log getInstance() {
		if (log == null) {
			log = new Log();
		}
		return log;
	
	}
	 
}
