package com.fdmgroup.app;

public interface Iterator {

	public boolean hasNext();
	public Object getNext();
	
}
