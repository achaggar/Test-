package com.fdmgroup.app;

public interface Collection {

	
	public Iterator createIterator();
	
}
