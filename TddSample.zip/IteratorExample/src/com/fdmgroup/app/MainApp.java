package com.fdmgroup.app;

import com.fdmgroup.app.Iterator;

public class MainApp {

	public static void main (String[] args) {
		IntCollection intCol  = new IntCollection();
		intCol.addInt(1);
		intCol.addInt(2);
		intCol.addInt(3);
		intCol.addInt(4);
		
		
		Iterator intIterator = intCol.createIterator(); 
        while (intIterator.hasNext()) { 
            System.out.println(intIterator.getNext()); 
        } 
	}
	
	
}
