package com.fdmgroup.app;

import java.util.ArrayList;
import java.util.List;

public class IntCollection implements Collection {

	List<Integer> intList ;
	
	
	public IntCollection() {
		super();
		intList = new ArrayList<>();	// TODO Auto-generated constructor stub
	}


	public void addInt(Integer i ) {
		intList.add(i);
	}
	
	@Override
	public Iterator createIterator() {
		return new IntIreator(intList);
		
	}

	//private class
	
	
	private class IntIreator implements Iterator{

		
		List<Integer> intList;
		int pos = 0;
		
		
		@Override
		public boolean hasNext() {
			
			if(pos>=intList.size() || intList.get(pos)==null) {
				return false;
			}
			else 
			{
				return true;
			}
			
		}

		public IntIreator(List<Integer> intList) {
			super();
			this.intList =intList;
		}

		@Override
		public Object getNext() {
			Integer i = intList.get(pos);
			pos = pos+1;
			return i;
		}
		
	}
	
}
