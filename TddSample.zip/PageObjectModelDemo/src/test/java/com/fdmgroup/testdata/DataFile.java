//this file contains all the data variables

package com.fdmgroup.testdata;



public class DataFile {

	public static String HomeURL = "http://unxbtn001/TradingPlatform_CLEAN/";
	
		public static String userTitle = "Mr";
		public static String userFirstName = "Lionel";
		public static String userSurname = "Messi";
		public static String userEmail = "LeoMessi10@test.com";
		public static String userUserName = "LeoMessi10";
		public static String userPassword = "Pass123";
		public static String userSecurityQuestion = "What is your favourite fruit?";
		public static String userSecurityAnswer = "Apple";
		public static String welcomeMessage = "Welcome to the Trading Platform " + userFirstName;
		public static String userNameMessage = "Your username is " + userUserName;
		public static String userHomePageWelcomeMessage = "Hello " + userFirstName;
		public static String enteredAmount = "150,000.00";
		public static String transactedShares = "100";
		public static String transactedSharesInHistoryPage = "408.41";

}
