package com.fdmgroup.webpages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RegistrationPage {

	
	public static WebElement titleDropDown(WebDriver driver) {
		return driver.findElement(By.name("title"));
	}
	
	public static WebElement firstNameField(WebDriver driver) {
		return driver.findElement(By.name("firstName"));
	}
	
	public static WebElement lastNameField(WebDriver driver) {
		return driver.findElement(By.name("lastName"));
	}
	
	public static WebElement emailField(WebDriver driver) {
		return driver.findElement(By.name("email"));
	}
	
	public static WebElement usernameField(WebDriver driver) {
		return driver.findElement(By.name("username"));
	}
	
	public static WebElement passwordField(WebDriver driver) {
		return driver.findElement(By.name("password"));
	}
	public static WebElement confirmPasswordField(WebDriver driver) {
		return driver.findElement(By.name("confirmPassword"));
	}
	public static WebElement SecurityQuestionDropDown(WebDriver driver) {
		return driver.findElement(By.name("question"));
	}
	public static WebElement answerField(WebDriver driver) {
		return driver.findElement(By.name("answer"));
	}
	public static WebElement confirmAnswer(WebDriver driver) {
		return driver.findElement(By.name("confirmAnswer"));
	}
	
	public static WebElement submitButton(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id=\"user\"]/table/tbody/tr[11]/td[2]/input[1]"));
	}
	
	
	
	
}
