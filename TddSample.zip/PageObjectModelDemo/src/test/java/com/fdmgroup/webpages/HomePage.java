package com.fdmgroup.webpages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {


	
		public static WebElement userHomePageWelcomeMessage(WebDriver driver) {
			
			return driver.findElement(By.tagName("h3"));
			
			
		}
		
		
	}
	

