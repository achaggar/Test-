package com.fdmgroup.webpages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class BuyStockPage {

	//WebDriver driver
	
	public static WebElement buyStockLink(WebDriver driver) {
		return driver.findElement(By.linkText("Buy Stock"));
		

		
	}
	
	public static WebElement gLink(WebDriver driver) {
		return driver.findElement(By.linkText("G"));
		
	}
	
	public static WebElement radioButton(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id=\"GLEN.L\"]/td[4]/input"));
		
	}
	
	public static WebElement buyButton(WebDriver driver) {
		
		return driver.findElement(By.xpath("//*[@id=\"submitBtn\"]"));
		
	}
	
	public static WebElement enterAmount(WebDriver driver) {
		return driver.findElement(By.name("amount"));
	}
	
	public static WebElement calculatebutton(WebDriver driver) {
		return driver.findElement(By.id("calcBtn"));
		
	}
	
	public static WebElement confirmButton(WebDriver driver) {
		
		return driver.findElement(By.xpath("//*[@id=\"transaction_summary\"]/form/input[3]"));
		
	}
	
	public static WebElement transactionHistory(WebDriver driver) {
		return driver.findElement(By.linkText("TRANSACTION HISTORY"));
		
	}
	
}
