package com.fdmgroup.webpages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {

	
	public static WebElement registerLink(WebDriver driver) {
		return driver.findElement(By.linkText("Register"));
		
		}
	
	
	public static WebElement usernameField(WebDriver driver) {
		
		
		return driver.findElement(By.name("j_username"));
		
	}
	public static WebElement passwordField(WebDriver driver) {
		return driver.findElement(By.name("j_password"));
		
	}
	public static WebElement submitButton(WebDriver driver) {
		return driver.findElement(By.name("submit"));
		
	}
	
	
}
