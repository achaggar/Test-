package com.fdmgroup.webpages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RegistrationConfirmationPage {

	public static WebElement userWelcomeMessageLabel(WebDriver driver) {
		return driver.findElement(By.tagName("h3"));
		
	}
	public static WebElement userNameMessageLabel(WebDriver driver) {
		return driver.findElement(By.tagName("p"));
		
	}
	
	public static WebElement loginLink(WebDriver driver) {
		return driver.findElement(By.linkText("Login"));
	}
}
