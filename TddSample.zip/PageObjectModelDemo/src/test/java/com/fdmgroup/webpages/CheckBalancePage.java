package com.fdmgroup.webpages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CheckBalancePage {

	
	public static WebElement checkBalanceLink(WebDriver driver) {
		
		return driver.findElement(By.linkText("Check Balance"));
	}
	
	public static WebElement addNewAccount(WebDriver driver) {
		return driver.findElement(By.linkText("Add New Account"));
		
	}
	
	
	public static WebElement currencyDropDown(WebDriver driver) {
		
		return driver.findElement(By.name("currency"));
		
	}
	
	public static WebElement addAccountButton(WebDriver driver) {
		
		return driver.findElement(By.xpath("//*[@id=\"command\"]/table/tbody/tr/td[3]/input"));
		
	}
	
	
	public static WebElement addFunds(WebDriver driver ) {
		
		return driver.findElement(By.xpath("//*[@id=\"main\"]/table/tbody/tr[5]/td[4]/form/input[4]"));
	}
	
	
	public static WebElement enterAmount(WebDriver driver ) {
		
		return driver.findElement(By.xpath("//*[@id=\"updateForm\"]/form/input[4]"));
	}
	
	public static WebElement confirmButton(WebDriver driver) {
		
		return driver.findElement(By.xpath("//*[@id=\"submitBtn\"]"));
		
	}
	
	
}
