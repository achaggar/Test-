package com.fdmgroup.testScript;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.fdmgroup.testdata.DataFile;
import com.fdmgroup.util.DriverUtilities;
import com.fdmgroup.webpages.LoginPage;
import com.fdmgroup.webpages.RegistrationConfirmationPage;
import com.fdmgroup.webpages.RegistrationPage;

public class RegistrationTest {

	private DriverUtilities driverUtilities;
	private WebDriver driver;
	
	@Before
	public void init() {
	
		driverUtilities = DriverUtilities.getInstance();
		driver = driverUtilities.getDriver();
		
	}
	
@Test

public void registerTest() {
	driver.get(DataFile.HomeURL);
	
LoginPage.registerLink(driver).click();


WebElement titleDropDown=RegistrationPage.titleDropDown(driver);
Select titleSelected = new Select(titleDropDown);
titleSelected.selectByVisibleText(DataFile.userTitle);


RegistrationPage.firstNameField(driver).sendKeys(DataFile.userFirstName);
RegistrationPage.lastNameField(driver).sendKeys(DataFile.userSurname);
RegistrationPage.emailField(driver).sendKeys(DataFile.userEmail);
RegistrationPage.usernameField(driver).sendKeys(DataFile.userUserName);
RegistrationPage.passwordField(driver).sendKeys(DataFile.userPassword);
RegistrationPage.confirmPasswordField(driver).sendKeys(DataFile.userPassword);

WebElement securityQuestionDropDown = RegistrationPage.SecurityQuestionDropDown(driver);
Select questionSelected = new Select(securityQuestionDropDown);
questionSelected.selectByVisibleText(DataFile.userSecurityQuestion);


RegistrationPage.answerField(driver).sendKeys(DataFile.userSecurityAnswer);
RegistrationPage.confirmAnswer(driver).sendKeys(DataFile.userSecurityAnswer);

RegistrationPage.submitButton(driver).click();

//assert welcome
String actualUserWelcomeMessage = RegistrationConfirmationPage.userWelcomeMessageLabel(driver).getText();
assertEquals(DataFile.welcomeMessage,actualUserWelcomeMessage);

//assert username
String actualUserName = RegistrationConfirmationPage.userNameMessageLabel(driver).getText();
assertEquals(DataFile.userNameMessage, actualUserName);

RegistrationConfirmationPage.loginLink(driver).click();


}

}
