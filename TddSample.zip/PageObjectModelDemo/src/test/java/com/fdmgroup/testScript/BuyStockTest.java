package com.fdmgroup.testScript;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import static org.junit.Assert.assertEquals;

import com.fdmgroup.testdata.DataFile;
import com.fdmgroup.util.DriverUtilities;
import com.fdmgroup.webpages.BuyStockPage;

public class BuyStockTest {

	private DriverUtilities driverUtilities;
	private WebDriver driver;


	@Before
	public void init() {
		
		driverUtilities = DriverUtilities.getInstance();
		driver = driverUtilities.getDriver();
	}
	
	@Test 
	public void stockBuy() throws InterruptedException {
		
		BuyStockPage.buyStockLink(driver).click();
		BuyStockPage.gLink(driver).click();
		BuyStockPage.radioButton(driver).click();
		BuyStockPage.buyButton(driver).click();
		BuyStockPage.enterAmount(driver).sendKeys("100");
		BuyStockPage.calculatebutton(driver).click();
		Thread.sleep(1000);
		BuyStockPage.confirmButton(driver).click();
		BuyStockPage.transactionHistory(driver).click();
		
		
		//assert the no of shares
		
	String transacted = driver.findElement(By.xpath("//*[@id=\"transaction_summary\"]/table/tbody/tr[3]/td[2]")).getText();
	assertEquals(DataFile.transactedShares,transacted);
		
	String transactedInHistory = driver.findElement(By.xpath("//*[@id=\"transaction_history\"]/tbody/tr[1]/td[5]")).getText();
	assertEquals(DataFile.transactedSharesInHistoryPage,transactedInHistory);
	
		
	}
	
}
