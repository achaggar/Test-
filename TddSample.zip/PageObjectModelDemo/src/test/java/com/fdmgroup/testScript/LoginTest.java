package com.fdmgroup.testScript;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import static org.junit.Assert.assertEquals;
import com.fdmgroup.testdata.DataFile;
import com.fdmgroup.util.DriverUtilities;
import com.fdmgroup.webpages.HomePage;
import com.fdmgroup.webpages.LoginPage;

public class LoginTest {
private DriverUtilities driverUtilities;
private WebDriver driver;


@Before
public void init() {
	
	driverUtilities = DriverUtilities.getInstance();
	driver = driverUtilities.getDriver();
}
	

@Test 
public void loginTest() {
	
	driver.get(DataFile.HomeURL);
	LoginPage.usernameField(driver).sendKeys(DataFile.userUserName);
	LoginPage.passwordField(driver).sendKeys(DataFile.userPassword);
	LoginPage.submitButton(driver).click();

String actualUserHomePageWelcomeMessage = HomePage.userHomePageWelcomeMessage(driver).getText();
assertEquals(DataFile.userHomePageWelcomeMessage,actualUserHomePageWelcomeMessage);
	
}



	
}
