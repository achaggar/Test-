package com.fdmgroup.testScript;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.fdmgroup.testdata.DataFile;
import com.fdmgroup.util.DriverUtilities;
import com.fdmgroup.webpages.CheckBalancePage;
import com.fdmgroup.webpages.LoginPage;
import static org.junit.Assert.assertEquals;
public class NewCurrencyAccountTest {

	private DriverUtilities driverUtilities;
	private WebDriver driver;
	
	@Before
	public void init() {
	
		driverUtilities = DriverUtilities.getInstance();
		driver = driverUtilities.getDriver();
		
	}
	
@Test
public void addAccount() throws InterruptedException {
	
	CheckBalancePage.checkBalanceLink(driver).click();
	//CheckBalancePage.addNewAccount(driver).click();
	
	/*WebElement currencyDropDown = CheckBalancePage.currencyDropDown(driver);
	Select currency = new Select(currencyDropDown);
	currency.selectByIndex(1);
	
	CheckBalancePage.addAccountButton(driver).click();
*/	
	CheckBalancePage.addFunds(driver).click();
	Thread.sleep(1000);
	CheckBalancePage.enterAmount(driver).sendKeys("50000");
	CheckBalancePage.confirmButton(driver).click();
	
	
	//assert balance 
	
	String shownbalance = driver.findElement(By.xpath("//*[@id=\"main\"]/table/tbody/tr[5]/td[3]")).getText();
	assertEquals(DataFile.enteredAmount,shownbalance);
	
	
}


	
	
}
