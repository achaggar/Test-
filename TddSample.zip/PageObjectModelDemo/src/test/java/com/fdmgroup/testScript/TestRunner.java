package com.fdmgroup.testScript;
// this is a test suite that will define the sequence of the tests

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith (Suite.class)

@SuiteClasses({
	//RegistrationTest.class,
	LoginTest.class,
//	NewCurrencyAccountTest.class
	BuyStockTest.class
	
})

public class TestRunner {

	
	
}
