package com.fdmgroup.app;

public class BuubleSort {

public static void bubble (int array[]) {
	
	int n = array.length;
	int k;
	for (int m =n ; m>0;m--) {
		for (int i=0; i<n-1;i++) {
			k=i+1;
			if(array[i]>array[k]) {
				swapNumber(i,k,array);
			}
		}
	}
	
		
		
	}

private static void swapNumber(int i, int j, int[] array) {
	// TODO Auto-generated method stub
	
	int temp;
	temp = array[i];
	array[i]= array[j];
	array[j] = temp;
	
}

	
	
	
}
