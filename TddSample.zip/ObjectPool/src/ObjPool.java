import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public class ObjPool {

	
	private ConcurrentLinkedQueue<T> pool;
	
	private ScheduledExecutorService executorService;

	public ObjPool() {
		super();
		
		initialize(minObjects);
 }
	
	public ObjPool(final int minObjects,final int maxObjects,final long validationInterval) {
		super();
		
		initialize(minObjects);
	
		executorService = Executors.newSingleThreadScheduledExecutor();
		executorService.scheduleWithFixedDelay(new Runnable()
				{
			public void run()
			{
				int size = pool.size();
				if (size<minObjects)
				{
					int sizeTobeAdded = minObjects + size;
				}
			}
				}
	
	
	}
	
	
	

	
	
}
