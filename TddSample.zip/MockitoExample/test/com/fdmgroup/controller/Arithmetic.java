package com.fdmgroup.controller;


import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

import org.junit.BeforeClass;
import org.junit.Test;


public class Arithmetic {

	static Arithmet ar;
	static AdvancedArithmetic mockar;
	
	@BeforeClass
	
	
	public static void init() {
	mockar= mock(AdvancedArithmetic.class);	
	ar = mock(Arithmet.class);
	
	
	//stubbing the values
	
	when(mockar.sum(2, 3)).thenReturn(5);
	}
	
	
	@Test 
	public void testSum() {
		int result = ar.sum(2, 3);
		assertEquals(15,result);
		verify(mockar,times(1)).sum(2, 3);
				
	}
	
}
