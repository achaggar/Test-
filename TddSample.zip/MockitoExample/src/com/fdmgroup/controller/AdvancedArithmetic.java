package com.fdmgroup.controller;

public interface AdvancedArithmetic {

	int sum(int num1 , int num2);
	
	
	

}
