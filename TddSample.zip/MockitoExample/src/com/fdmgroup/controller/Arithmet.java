package com.fdmgroup.controller;

public class Arithmet {

	AdvancedArithmetic advArithmetic;
	


	public Arithmet(AdvancedArithmetic advArithmetic) {
		super();
	    this.advArithmetic = advArithmetic;
	}



	public int sum (int num1, int num2) {
		
		return num1+num2;
		
	}
	
}
