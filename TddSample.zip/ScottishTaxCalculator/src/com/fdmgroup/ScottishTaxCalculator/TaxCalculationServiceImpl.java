package com.fdmgroup.ScottishTaxCalculator;

public final class TaxCalculationServiceImpl implements TaxCalculationService {

	@Override
	public double getTaxRate(double income) {
		
		if (income <= 11500) {
			return 0.0;
			
		}else if (income >= 11851 && income <=13850) {
			return 19.0;}
		
		
			else if (income >= 13851 && income <=24000) {
				return 20.0;}
		
				else if (income >= 24001 && income <=44273) {
					return 21.0;}
		
				else if (income >= 44274 && income <=150000) {
					return 41.0;}
				else
					return 46;
		
							
		
		
	}

}
