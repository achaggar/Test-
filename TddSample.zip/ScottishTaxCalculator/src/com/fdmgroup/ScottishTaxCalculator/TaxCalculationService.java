package com.fdmgroup.ScottishTaxCalculator;

public interface TaxCalculationService  {

	public double getTaxRate(double income);
	
	
	
	
	
}
