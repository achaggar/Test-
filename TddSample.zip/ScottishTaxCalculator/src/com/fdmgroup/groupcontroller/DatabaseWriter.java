package com.fdmgroup.groupcontroller;

public class DatabaseWriter {

	public void addTrainee(Trainee trainee) {
		
	}

	public void deleteTraineeByUsername(String anyString) {
		
	}
	
}
