package com.fdmgroup.groupcontroller;

public class Trainee {

}
