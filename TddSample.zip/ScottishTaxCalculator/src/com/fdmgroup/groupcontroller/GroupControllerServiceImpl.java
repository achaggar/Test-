package com.fdmgroup.groupcontroller;

import java.util.Map;

public class GroupControllerServiceImpl implements GroupControllerService{

	DatabaseReader databasereader;
	DatabaseWriter databasewriter;
	
	
	
	
	public GroupControllerServiceImpl(DatabaseReader databasereader, DatabaseWriter databasewriter) {
		super();
		this.databasereader = databasereader;
		this.databasewriter = databasewriter;
	}

	public GroupControllerServiceImpl() {
	
	}

	@Override
	public Map<String, Trainee> getAllTrainees() {
		
		return databasereader.readGroup();
	}

	@Override
	public void addTrainee(Trainee trainee) {
		
		databasewriter.addTrainee(trainee);
		
	}

	@Override
	public void removeTraineeByUsername(String traineeUsername) {
		databasewriter.deleteTraineeByUsername(traineeUsername);
		
	}

	
	
}
