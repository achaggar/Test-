package com.fdmgroup.ScottishTaxCalculatorTest;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.fdmgroup.ScottishTaxCalculator.TaxCalculationServiceImpl;

public class ScottishTaxCalculatorTest {
	
TaxCalculationServiceImpl scottishtaxCal = new  TaxCalculationServiceImpl();
double income;


	@Test
	public void test_lessthanEqualTo11500() {
		
		
		double result = scottishtaxCal.getTaxRate(11500);
		assertEquals(0.0,result,0.01);
		
	}
	@Test
	public void test_lessthanEqualTo13850() {
		
		double result = scottishtaxCal.getTaxRate(12900);
		assertEquals(19.0,result,0.01);
		
		
	}
	
	
	@Test
	public void test_lessthanEqualTo24000() {
		double result = scottishtaxCal.getTaxRate(13900);
		assertEquals(20.0,result,0.01);
	}
	
	
	@Test
	public void test_lessthanEqualTo44273() {
		double result = scottishtaxCal.getTaxRate(25000);
		assertEquals(21.0,result,0.01);
	}
	
	
	@Test
	public void test_lessthanEqualTo150000() {
		double result = scottishtaxCal.getTaxRate(45500);
		assertEquals(41.0,result,0.01);
	}
	@Test
	public void test_Greaterthan150000() {
		double result = scottishtaxCal.getTaxRate(160000);
		assertEquals(46.0,result,0.01);
	}
	

	
}
