package com.fdmgroup.GroupControllerServiceTest;

import com.fdmgroup.groupcontroller.DatabaseReader;
import com.fdmgroup.groupcontroller.DatabaseWriter;
import com.fdmgroup.groupcontroller.GroupControllerServiceImpl;
import static org.mockito.Mockito.*;
public class GroupControllerServiceTest {

	
	
	
	 public void test_getTrainee() {
		 
		DatabaseReader mockDatabaseReader = mock(DatabaseReader.class);
		GroupControllerServiceImpl groupContServ = new GroupControllerServiceImpl(mockDatabaseReader, null);
		groupContServ.getAllTrainees();
		verify(mockDatabaseReader.readGroup());
		
		 
	 }
	 public void test_AddTrainee() {
		 
		DatabaseWriter mockDatabaseWriter = mock(DatabaseWriter.class);
		GroupControllerServiceImpl groupContServ = new GroupControllerServiceImpl(null, mockDatabaseWriter);
		groupContServ.addTrainee(null);
//		verify(mockDatabaseWriter.addTrainee(trainee);
		
		 
	 }
	 
	 
	 public void test_RemoveTraineeByUsername() {
		 
		
		 
		 
	 }
	
	
	
}
