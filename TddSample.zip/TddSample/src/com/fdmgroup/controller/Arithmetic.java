package com.fdmgroup.controller;

public class Arithmetic {

	public int sum(int i, int j) {
		
		return i+j;
	}

	public int multiply(int i, int j) {
		
		return i*j;
	}

}
