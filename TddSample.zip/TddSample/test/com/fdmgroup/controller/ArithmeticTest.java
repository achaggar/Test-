package com.fdmgroup.controller;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class ArithmeticTest {
	
	Arithmetic ar;
	
	@Before
	public void init() {
		ar=new Arithmetic();
	}

	@Test 
	public void sumTest() {
		int result = ar.sum(2,3);
		assertEquals(5,result);
	}
	@Test 
	public void multiplicationTest() {
		int result = ar.multiply(2,3);
		assertEquals(6,result);
	}
	
}
